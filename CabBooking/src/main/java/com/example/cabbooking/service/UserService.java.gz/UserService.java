package com.example.cabbooking.service;

import java.util.HashMap;

import org.springframework.stereotype.Service;

import com.example.cabbooking.model.Driver;
import com.example.cabbooking.model.User;

@Service
public class UserService {

	public HashMap<String, User> userMap;

	public UserService() {
		userMap = new HashMap<>();
		userMap.put("Nik", new Driver("Nik", "Nikhila", "Nik@gmail.com", "1234567"));
		userMap.put("Pick", new Driver("Pick", "Nikhila", "Nik@gmail.com", "1234567"));
		userMap.put("Mik", new Driver("Mik", "Nikhila", "Nik@gmail.com", "1234567"));
	}

	public void addUser(User user) {
		userMap.put(user.getId(), user);
	}

	public void notifyDriver(User driver) {

	}

}
