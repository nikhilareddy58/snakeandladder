package com.example.cabbooking.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.cabbooking.model.Address;
import com.example.cabbooking.model.Booking;
import com.example.cabbooking.model.BookingStatus;
import com.example.cabbooking.model.Cab;
import com.example.cabbooking.model.Customer;
import com.example.cabbooking.model.User;

@Service
public class BookingManagerService {

	public static Integer bookingId = 0;

	@Autowired
	CabService cabService;

	public HashMap<String, Booking> bookingMap;

	public BookingManagerService() {
		bookingMap = new HashMap<String, Booking>();
	}

	public Booking createBooking(User user, Address startAddress, Address destAddress, Optional<Integer> capacity) {
		Booking booking = new Booking();
		booking.setBookingId(bookingId++ + "");
		System.out.println("Booking ID generated "+booking.getBookingId());
		booking.setBookingTime(new Date());
		booking.setBookedBy((Customer) user);
		booking.setBookingStatus(BookingStatus.OPEN);
		booking.setDestAddress(destAddress);
		List<Cab> cabsList = cabService.getCabs(startAddress, capacity);
		for (Cab cab : cabsList) {
			cab.getDriver().notifyUser(booking);
		}
		bookingMap.put(booking.getBookingId(), booking);
		return booking;
	}

	public Booking updateBooking(Cab cab, Booking booking, BookingStatus bookingStatus) {
		Booking tempBooking = bookingMap.get(bookingId);
		if (tempBooking != null
				&& (!tempBooking.getBookingStatus().equals(BookingStatus.OPEN) || cab.equals(tempBooking.getCab()))) {
			booking.setBookingStatus(bookingStatus);
			booking.setCab(cab);
			if (bookingStatus.equals(BookingStatus.CONFIRMED))
				cabService.removeCab(cab);
			else
				cabService.addCabs(cab);
			bookingMap.put(booking.getBookingId(), booking);
		}
		return booking;
	}

}
