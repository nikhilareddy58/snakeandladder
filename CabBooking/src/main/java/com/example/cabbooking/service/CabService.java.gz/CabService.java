package com.example.cabbooking.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.cabbooking.model.Address;
import com.example.cabbooking.model.Cab;
import com.example.cabbooking.model.Driver;
import com.example.cabbooking.model.FourSeaterCab;
import com.example.cabbooking.model.SixSeaterCab;
import com.example.cabbooking.model.User;

@Service
public class CabService {

	public HashMap<String, Cab> availableCabPool;

	public HashMap<String, Cab> unAvailableCabPool;
	
	@Autowired
	public UserService userService;

	public CabService() {
	}
	@PostConstruct
    public void init() {
		availableCabPool=new HashMap<>();
		unAvailableCabPool= new HashMap<>();
		HashMap<String, User> userMap= userService.userMap;
		availableCabPool.put("1", new FourSeaterCab("1", true, new Address("10","10"),(Driver) userMap.get("Nik")));
		availableCabPool.put("2", new SixSeaterCab("2", true,new Address("10","10"),(Driver) userMap.get("Pick")));
		availableCabPool.put("3", new FourSeaterCab("3", true,new Address("10","10"),(Driver) userMap.get("Mik")));
	
    }

	public void addCabs(Cab cab) {
		availableCabPool.put(cab.getCabId(), cab);
		unAvailableCabPool.remove(cab.getCabId());
	}
	
	
	public void removeCab(Cab cab) {
		Cab tempCab= availableCabPool.get(cab.getCabId());
		availableCabPool.remove(cab.getCabId());
		tempCab.setAvailable(false);
		unAvailableCabPool.put(cab.getCabId(),tempCab);
	}

	public List<Cab> getCabs(Address address, Optional<Integer> capacity) {
		List<Cab> availableCabList= new ArrayList<>();
		for(Map.Entry  map:availableCabPool.entrySet()) {
			availableCabList.add((Cab) map.getValue());
		}
		return availableCabList.stream()
				.filter(x -> x.getAddress().equals(address)).collect(Collectors.toList());
	}

}
