package com.example.cabbooking.model;

public class SixSeaterCab extends Cab {
	
	public SixSeaterCab(String cabId, boolean isAvailable,Address address,Driver driver) {
		this.setCabId(cabId);
		this.setAvailable(isAvailable);
		this.setCapacity(6);
		this.setAddress(address);
		this.setDriver(driver);
	}
	

	@Override
	public Integer calculatePrice() {
		this.setPrice(100*this.getCapacity());
		return this.getPrice();
	}

}
