package com.example.cabbooking.model;

public class FourSeaterCab extends Cab{

	public FourSeaterCab(String cabId, boolean isAvailable, Address address,Driver driver) {
		this.setCabId(cabId);
		this.setAvailable(isAvailable);
		this.setCapacity(4);
		this.setAddress(address);
		this.setDriver(driver);

	}
	
	@Override
	public Integer calculatePrice() {
		this.setPrice(100*this.getCapacity());
		return this.getPrice();
	}

}
