package com.example.cabbooking.model;

public abstract class User {
	
	private String id;
	private String name;
	private String emailId;
	private String contactId;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getContactId() {
		return contactId;
	}
	public User(String id, String name, String emailId, String contactId) {
		super();
		this.id = id;
		this.name = name;
		this.emailId = emailId;
		this.contactId = contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	
	public abstract Booking notifyUser(Booking booking);
	
	

}
