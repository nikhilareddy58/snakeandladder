package com.example.cabbooking.model;

public class Driver extends User{

	public Driver(String id, String name, String emailId, String contactId) {
		super(id, name, emailId, contactId);
	}

	@Override
	public Booking notifyUser(Booking booking) {
		return booking;
	}

}
