package com.example.cabbooking.model;

import java.util.Date;

public class Booking {
	
	private BookingStatus bookingStatus;
	private String bookingId;
	private Customer bookedBy;
	private Date bookingTime;
	private Address address;
	private Cab cab;
	private Address destAddress;

	
	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public Customer getBookedBy() {
		return bookedBy;
	}
	public void setBookedBy(Customer bookedBy) {
		this.bookedBy = bookedBy;
	}
	public Date getBookingTime() {
		return bookingTime;
	}
	public void setBookingTime(Date bookingTime) {
		this.bookingTime = bookingTime;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Cab getCab() {
		return cab;
	}
	public void setCab(Cab cab) {
		this.cab = cab;
	}
	public Address getDestAddress() {
		return destAddress;
	}
	public void setDestAddress(Address destAddress) {
		this.destAddress = destAddress;
	}
	

}
