package com.example.cabbooking.model;

import java.util.Optional;


public class CabRequestBody {
	
	private Customer user;
	private Address startAddress;
	private Address destAddress;
	private Optional<Integer> capacity;
	
	public Customer getUser() {
		return user;
	}
	public void setUser(Customer user) {
		this.user = user;
	}
	public Address getStartAddress() {
		return startAddress;
	}
	public void setStartAddress(Address startAddress) {
		this.startAddress = startAddress;
	}
	public Address getDestAddress() {
		return destAddress;
	}
	public void setDestAddress(Address destAddress) {
		this.destAddress = destAddress;
	}
	public Optional<Integer> getCapacity() {
		return capacity;
	}
	public void setCapacity(Optional<Integer> capacity) {
		this.capacity = capacity;
	}
}
