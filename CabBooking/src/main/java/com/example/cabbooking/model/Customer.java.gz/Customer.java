package com.example.cabbooking.model;

public class Customer extends User{

	public Customer(String id, String name, String emailId, String contactId) {
		super(id, name, emailId, contactId);
	}

	@Override
	public Booking notifyUser(Booking booking) {
		System.out.println("Please accept Booking, "+this.getName());
		return booking;
	}

}
