package com.example.cabbooking.model;

public enum BookingStatus {
	
	OPEN,
	CONFIRMED,
	USER_CANCELLED,
	DRIVER_CANCELLED,
	COMPLETED,
	UNKNOWN;

}
