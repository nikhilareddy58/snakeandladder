package com.example.cabbooking.model;

public abstract class Cab {
	
	private String cabId;
	private Integer capacity;
	private Boolean isAvailable;
	private Integer price;
	private Address address;
	private Driver driver;
	
	
	public String getCabId() {
		return cabId;
	}
	public void setCabId(String cabId) {
		this.cabId = cabId;
	}
	public Integer getCapacity() {
		return capacity;
	}
	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}
	public Boolean isAvailable() {
		return isAvailable;
	}
	public void setAvailable(Boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public abstract Integer calculatePrice() ;
	
	
	public Driver getDriver() {
		return driver;
	}
	public void setDriver(Driver driver) {
		this.driver = driver;
	}
	

}
