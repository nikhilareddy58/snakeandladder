package com.example.cabbooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.cabbooking.model.Booking;
import com.example.cabbooking.model.BookingStatus;
import com.example.cabbooking.model.Cab;
import com.example.cabbooking.model.CabRequestBody;
import com.example.cabbooking.service.BookingManagerService;

@RestController
public class BookingController {

	@Autowired
	BookingManagerService bookingManagerService;

	@RequestMapping(value = "/requestBooking", method = RequestMethod.POST)
	public Booking requestBooking(@RequestBody CabRequestBody cabReqBody) {
		System.out.println("Cab booking request initiated");
		return bookingManagerService.createBooking(cabReqBody.getUser(), cabReqBody.getStartAddress(),
				cabReqBody.getDestAddress(), cabReqBody.getCapacity());
	}

	@RequestMapping(value = "/updateBooking", method = RequestMethod.POST)
	public Booking updateBooking(Booking booking, Cab cab, BookingStatus bookingStatus) {
		return bookingManagerService.updateBooking(cab, booking, bookingStatus);
	}

}
